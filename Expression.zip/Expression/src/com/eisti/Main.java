package com.eisti;

public class Main {

    public static void main(String[] args) {
        //fill_the_blank r =new fill_the_blank();
        //Guess_the_expression g = new Guess_the_expression();
        //test t = new test();
        //filestest tf=new filestest();
    }
}
