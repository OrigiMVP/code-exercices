package com.eisti;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class test {
    private int i;
    private int min;
    private int max;
    private ArrayList<String> data;
    private String mot_solution;
    private String mot_cache;
    private String etoiles;

    test (){
        try {
            data = new ArrayList<>(Files.readAllLines(Paths.get("E_A.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Welcome to the fill in the blank game !! ");



        Scanner in = new Scanner(System.in);
        System.out.println("Choose the number of exercises to practice today 5,10 or 20 exercises:");
        int num_ex = in.nextInt();

        while(num_ex!=5&num_ex!=10&num_ex!=20)
        {
            System.out.println("Wrong input try again");
            System.out.println("Choose the number of exercises to practice today 5,10 or 20 exercises:");
            num_ex = in.nextInt();
        }


        if (num_ex==5){
            max=297;
            min=0;
            for (i=1;i<5;i++){
                Random r = new Random();
                int n = min + r.nextInt(max - min);
                assert data != null;
                mot_solution=data.get(n);
                String[] array_of_string = mot_solution.split(" ");
                for(int i = 0; i <= array_of_string.length-1; i++)
                {
                    if (array_of_string.length%2==0 & i%2==0){
                        etoiles="";
                        for (int j = 0; j <= array_of_string[i].length()-1; j++){
                            etoiles+="*";
                        }
                        array_of_string[i]=etoiles;
                    }
                    if (array_of_string.length%2!=0 & i%2==0) {
                        etoiles="";
                        for (int j = 0; j <= array_of_string[i].length()-1; j++){
                            etoiles+="*";
                        }
                        array_of_string[i]=etoiles;
                    }
                }
                mot_cache="";
                for (int k =0; k<array_of_string.length; k++){
                    mot_cache += String.join(" ", array_of_string[k])+" ";
                }
                System.out.println("*********************************************");
                System.out.println("The expression: "+mot_cache);
                Scanner sc = new Scanner(System.in);
                System.out.println("Complete the expression please :");
                String str = sc.nextLine();
                if (!str.equals(mot_solution)) {
                    System.out.println("Wrong expression :( !");
                    System.out.println("The solution was  :" + mot_solution);
                }
                else{
                    System.out.println("Congratulations you guessed the correct expression :) !!");
                    max+=268;
                    min += 268;
                    if(max==1608){
                        max-=268;
                        min-=268;
                    }
                }
            }
        }
        if (num_ex==20){
            max=66;
            min=0;
            for (i=1;i<5;i++){
                Random r = new Random();
                int n = min + r.nextInt(max - min);
                assert data != null;
                mot_solution=data.get(n);
                String[] array_of_string = mot_solution.split(" ");
                for(int i = 0; i <= array_of_string.length-1; i++)
                {
                    if (array_of_string.length%2==0 & i%2==0){
                        etoiles="";
                        for (int j = 0; j <= array_of_string[i].length()-1; j++){
                            etoiles+="*";
                        }
                        array_of_string[i]=etoiles;
                    }
                    if (array_of_string.length%2!=0 & i%2==0) {
                        etoiles="";
                        for (int j = 0; j <= array_of_string[i].length()-1; j++){
                            etoiles+="*";
                        }
                        array_of_string[i]=etoiles;
                    }
                }
                mot_cache="";
                for (int k =0; k<array_of_string.length; k++){
                    mot_cache += String.join(" ", array_of_string[k])+" ";
                }
                System.out.println("*********************************************");
                System.out.println("The expression: "+mot_cache);
                Scanner sc = new Scanner(System.in);
                System.out.println("Complete the expression please :");
                String str = sc.nextLine();
                if (!str.equals(mot_solution)) {
                    System.out.println("Wrong expression :( !");
                    System.out.println("The solution was  :" + mot_solution);
                }
                else{
                    System.out.println("Congratulations you guessed the correct expression :) !!");
                    max+=67;
                    min += 67;
                    if(max==1407){
                        max-=67;
                        min-=67;
                    }
                }
            }
        }
        if (num_ex==10){
            max=133;
            min=0;
            for (i=1;i<5;i++){
                Random r = new Random();
                int n = min + r.nextInt(max - min);
                assert data != null;
                mot_solution=data.get(n);
                String[] array_of_string = mot_solution.split(" ");
                for(int i = 0; i <= array_of_string.length-1; i++)
                {
                    if (array_of_string.length%2==0 & i%2==0){
                        etoiles="";
                        for (int j = 0; j <= array_of_string[i].length()-1; j++){
                            etoiles+="*";
                        }
                        array_of_string[i]=etoiles;
                    }
                    if (array_of_string.length%2!=0 & i%2==0) {
                        etoiles="";
                        for (int j = 0; j <= array_of_string[i].length()-1; j++){
                            etoiles+="*";
                        }
                        array_of_string[i]=etoiles;
                    }
                }
                mot_cache="";
                for (int k =0; k<array_of_string.length; k++){
                    mot_cache += String.join(" ", array_of_string[k])+" ";
                }
                System.out.println("*********************************************");
                System.out.println("The expression: "+mot_cache);
                Scanner sc = new Scanner(System.in);
                System.out.println("Complete the expression please :");
                String str = sc.nextLine();
                if (!str.equals(mot_solution)) {
                    System.out.println("Wrong expression :( !");
                    System.out.println("The solution was  :" + mot_solution);
                }
                else{
                    System.out.println("Congratulations you guessed the correct expression :) !!");
                    max+=134;
                    min += 134;
                    if(max==1474){
                        max-=134;
                        min-=134;
                    }
                }
            }
        }
    }
}
