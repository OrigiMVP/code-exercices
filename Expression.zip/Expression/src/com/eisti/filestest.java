package com.eisti;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;

public class filestest {

    private ArrayList<String> expression;
    private ArrayList<String> definition;
    int i;
    int max;
    int min;



    filestest(){
        try {
            expression = new ArrayList<>(Files.readAllLines(Paths.get("E_A.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            definition = new ArrayList<>(Files.readAllLines(Paths.get("D_A.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(expression);
        System.out.println(expression.get(35));


        min=0;
        max=66;

        for (i=1;i<=20;i++){
            Random r = new Random();
            int n = min + r.nextInt(max - min);
            assert definition != null;
            System.out.println(n);
            max+=67;
            min += 67;
            if(max==1406){
                max-=67;
                min-=67;
            }

            System.out.println(i+"min = "+min);
            System.out.println(i+"max = "+max);

        }



    }


}
