package com.eisti;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Guess_the_expression {
    private int i;
    private int min;
    private int max;
    private ArrayList<String> expression;
    private ArrayList<String> definition;
    private ArrayList<String> difficulty;



    Guess_the_expression () {

        try {
            expression = new ArrayList<>(Files.readAllLines(Paths.get("E_A.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            definition = new ArrayList<>(Files.readAllLines(Paths.get("D_A.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            difficulty = new ArrayList<>(Files.readAllLines(Paths.get("Level_results.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Scanner in = new Scanner(System.in);
        System.out.println("Choose the number of exercises to practice today 5,10 or 20 exercises:");
        int num_ex = in.nextInt();

        while(num_ex!=5&num_ex!=10&num_ex!=20)
        {
            System.out.println("Wrong input try again");
            System.out.println("Choose the number of exercises to practice today 5,10 or 20 exercises:");
            num_ex = in.nextInt();
        }


        if (num_ex==5){
            max=297;
            min=0;
            for (i=1;i<5;i++){
                Random r = new Random();
                int n = min + r.nextInt(max - min);
                assert definition != null;
                System.out.println(n);
                System.out.println("The definition: "+definition.get(n));
                Scanner sc = new Scanner(System.in);
                System.out.println("Write the associated expression please :");
                String str = sc.nextLine();
                assert expression != null;
                if(!str.equals(expression.get(n)))
                {
                    System.out.println("Wrong answer ");
                    System.out.println("The answer was: "+expression.get(n));
                }
                else{System.out.println("Congratulations you guessed the correct expression :) !!");
                    max+=268;
                    min += 268;
                    if(max==1608){
                        max-=268;
                        min-=268;
                    }
                }
            }
        }
        if (num_ex==10){
            max=133;
            min=0;
            for (i=1;i<10;i++){
                Random r = new Random();
                int n = min + r.nextInt(max - min);
                assert definition != null;
                System.out.println(n);
                System.out.println("The definition: "+definition.get(n));
                Scanner sc = new Scanner(System.in);
                System.out.println("Write the associated expression please :");
                String str = sc.nextLine();
                assert expression != null;
                if(!str.equals(expression.get(n)))
                {
                    System.out.println("Wrong answer ");
                    System.out.println("The answer was: "+expression.get(n));
                }
                else{System.out.println("Congratulations you guessed the correct expression :) !!");
                    max+=134;
                    min += 134;
                    if(max==1474){
                        max-=134;
                        min-=134;
                    }
                }
            }
        }
        if (num_ex==20){
            max=66;
            min=0;
            for (i=1;i<20;i++){
                Random r = new Random();
                int n = min + r.nextInt(max - min);
                assert definition != null;
                System.out.println(n);
                System.out.println("The definition: "+definition.get(n));
                Scanner sc = new Scanner(System.in);
                System.out.println("Write the associated expression please :");
                String str = sc.nextLine();
                assert expression != null;
                if(!str.equals(expression.get(n)))
                {
                    System.out.println("Wrong answer ");
                    System.out.println("The answer was: "+expression.get(n));
                }
                else{System.out.println("Congratulations you guessed the correct expression :) !!");
                    max+=67;
                    min += 67;
                    if(max==1407){
                        max-=67;
                        min-=67;
                    }
                }
            }
        }
    }
}
